package com.qq1312952829.classes;

/**
 * 
 * @author Xiaobiqiang
 *�����
 */
public class TestProg {

	public static void main(String[] args) {
		new SaleSystemUI().displayUI();
	}

}
